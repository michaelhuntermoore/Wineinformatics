#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include<algorithm>
#include <utility>
using namespace std;

void calcJaccard(vector <vector <int>>&intersection, vector <vector <int>>&nomatch, vector <vector <int>>&zeroes, vector <vector <int>> wine, vector <vector <double>>&distJaccard, int r, int c, int t)
{
	int count = 0;
	c = c - 1;

	if (t == 1)
	{
		for (int i = 0; i < r; i++)
			for (int z = 0; z < r; z++)
				intersection[i][z] = 0;

		for (int i = 0; i < r; i++)
		{
			for (int j = 0; j < c; j++)
				for (int z = count; z < r; z++)
				{
					if (wine[i][j] == 1 && wine[z][j] == 1)
					{
						intersection[i][z]++;
						intersection[z][i]++;
					}
					else if (wine[i][j] == 1 && wine[z][j] != 1)
					{
						nomatch[i][z]++;
					}
					else if (wine[i][j] != 1 && wine[z][j] == 1)
					{
						nomatch[z][i]++;
					}
					else if (wine[i][j] == 0 && wine[z][j] == 0)
					{
						zeroes[i][z]++;
						zeroes[z][i]++;
					}
				}
			//cout << intersection[i][0] << " ";
			count++;
		}
	}

	for (int i = 0; i < r; i++)
		for (int z = 0; z < r; z++)
		{
			//cout << intersection[i][z] << endl;
			/*Jaccard*/	if (t == 1)
				distJaccard[i][z] = double(intersection[i][z]) / (double(intersection[i][z]) + double(nomatch[i][z]) + double(nomatch[z][i])); //Denominator doesn't need to include 0-0 pairs.
			/*Russ-Rao*/else if (t == 2)
				distJaccard[i][z] = double(intersection[i][z]) / double(c);
			/*Kulz*/	else if (t == 3)
				distJaccard[i][z] = double(intersection[i][z]) / (double(nomatch[i][z]) + double(nomatch[z][i]));
			/*Rogers-T*/else if (t == 4)
				distJaccard[i][z] = (intersection[i][z] + zeroes[i][z]) / (double(intersection[i][z]) + double(zeroes[i][z]) + 2.0*double(nomatch[i][z]) + 2.0*double(nomatch[z][i]));
			/*Dice*/	else if (t == 5)
				distJaccard[i][z] = double(intersection[i][z]) / (2.0*double(intersection[i][z]) + double(nomatch[i][z]) + double(nomatch[z][i]));
			/*Corr*/	else if (t == 6)
				distJaccard[i][z] = (double(intersection[i][z])*double(zeroes[i][z]) - double(nomatch[i][z])*double(nomatch[z][i])) / sqrt((double(nomatch[i][z]) + double(intersection[i][z]))*(double(nomatch[z][i]) + double(zeroes[i][z]))*(double(intersection[i][z]) + double(nomatch[z][i]))*(double(zeroes[i][z]) + double(nomatch[i][z])));
			/*Yule*/	else if (t == 7)
				distJaccard[i][z] = (double(intersection[i][z])*double(zeroes[i][z]) - double(nomatch[i][z])*double(nomatch[z][i])) / (double(intersection[i][z])*double(zeroes[i][z]) + double(nomatch[i][z])*double(nomatch[z][i]));
			/*Sok-Mich*/else if (t == 8)
				distJaccard[i][z] = (double(c) - (double(nomatch[i][z]) + double(nomatch[z][i]))) / double(c);
			if (i == z)
				distJaccard[i][z] = 0;
		}
}

void calcKNN(vector <vector <double>> &origJaccard, vector <vector <double>> &distJaccard, vector <vector <int>> wine, vector <vector <double>> &knn, vector <string> &names, vector <vector <double>> &distKNN, int c, int rTrain, int k)
{
	double correct = 0;
	double sumJaccard = 0.0, sumType = 0.0;
	vector <double> avgJaccard, avgType, prediction, actualType;
	avgJaccard.assign(rTrain, 0.0);
	avgType.assign(rTrain, 0.0);
	prediction.assign(rTrain, 0.0);
	actualType.assign(rTrain, 0.0);

	for (int i = 0; i < rTrain; i++)
		sort(distJaccard[i].rbegin(), distJaccard[i].rend());
	//cout << "Top KNN Average Type     Predicted Type     Actual Type" << endl
	//	<< "--------------------     --------------     -----------" << endl;
	for (int i = 0; i < rTrain; i++)
	{
		sumJaccard = 0.0;
		for (int j = 0; j < k; j++)
		{
			distKNN[i][j] = distJaccard[i][j];
			sumJaccard += distKNN[i][j];
		}
		actualType[i] = wine[i][c - 1];
		avgJaccard[i] = sumJaccard / double(k);
	}

	for (int z = 0; z < k; z++)
	{
		for (int i = 0; i < rTrain; i++)
		{
			for (int j = 0; j < rTrain; j++)
			{
				if (distKNN[i][z] == origJaccard[i][j])
				{
					knn[i][z] = wine[j][c - 1];
					break;
				}
			}
		}
	}

	for (int i = 0; i < rTrain; i++)
	{
		sumType = 0.0;
		for (int j = 0; j < k; j++)
		{
			sumType += knn[i][j];
			//cout << distKNN[i][j] << "," << nameKNN[i][j] << "," << knn[i][j] << ",";
		}
		//cout << endl;
		avgType[i] = double(sumType) / double(k);
		if (avgType[i] >= 0.5)
			prediction[i] = 1;
		else
			prediction[i] = 0;
		if (prediction[i] == actualType[i])
			correct++;
		//cout << fixed << setprecision(3) << avgType[i] << "                    " << fixed << setprecision(0) << prediction[i] << "                  " << actualType[i] << endl;
	}
	//cout << endl;
	cout << fixed << setprecision(4) <<"K - " << k << " ACCURACY " << 100.0*(correct / rTrain) << "%" << endl << endl;
}

void readFile(string fB, string fN, vector <vector <int>> &wine, int rB, int rN, int c)
{
	ifstream inFile;

	inFile.open(fB.c_str());
	for (int i = 0; i < rB; i++)
	{
		for (int j = 0; j < c; j++)
		{
			if (j == c - 1)
				wine[i][j] = 1;
			else
				inFile >> wine[i][j];
		}
	}
	inFile.close();

	inFile.open(fN.c_str());
	for (int i = 0; i < rN; i++)
	{
		for (int j = 0; j < c; j++)
		{
			if (j == c - 1)
				wine[i+rB][j] = 0;
			else
				inFile >> wine[i+rB][j];
		}
	}

	inFile.close();
}

int main()
{
	string B = "BordeauxPreProcess.csv", N = "NapaNoZeros.csv";
	int numBordeaux = 296, numCol = 446;
	int numNapa = 347/*351*/, numWine, numTrain;
	int stuff, randNum;
	int kMax = 13/*, t = 1*/;

	int go = 0;

	//numBordeaux = 10;
	//numNapa = 10;

	vector <string> names;
	vector <vector <int>> wine, intersection, nomatch, zeroes;
	vector <vector <double>> knn, distKNN;
	vector <vector <double>> origJaccard, distJaccard;

	numWine = numBordeaux + numNapa;
	numTrain = numWine/**0.1*/;

	/*srand(time(NULL));

	for (int i = 0; i < numTrain; i++)
	{
		randNum = rand() % (numWine - 1);
		for (int j = 0; j < numTrain)
			if ()
	}*/

	names.assign(numWine, "Null");
	intersection.resize(numWine, vector<int>(numWine, 0));
	nomatch.resize(numWine, vector<int>(numWine, 0));
	zeroes.resize(numWine, vector<int>(numWine, 0));
	wine.resize(numWine, vector<int>(numCol, 0));
	readFile(B, N, wine, numBordeaux, numNapa, numCol);

	for (int t = 1; t < 9; t++)
	{
		distJaccard.assign(numWine, vector<double>(numWine, 0.0));
		calcJaccard(intersection, nomatch, zeroes, wine, distJaccard, numWine, numCol, t);
		origJaccard.assign(numWine, vector<double>(numWine, 0.0));
		origJaccard = distJaccard;

		if (t == 1)
			cout << "JACCARDS" << endl << endl;
		else if (t == 2)
			cout << "RUSSEL-RAO" << endl << endl;
		else if (t == 3)
			cout << "KULZINSKY" << endl << endl;
		else if (t == 4)
			cout << "ROGERS-TANMOTO" << endl << endl;
		else if (t == 5)
			cout << "DICE" << endl << endl;
		else if (t == 6)
			cout << "CORRELATION" << endl << endl;
		else if (t == 7)
			cout << "YULE" << endl << endl;
		else if (t == 8)
			cout << "SOKAL-MICHENER" << endl << endl;

		for (int k = 3; k <= kMax; k += 2)
		{
			knn.assign(numWine, vector<double>(k, 0.0));
			distKNN.assign(numTrain, vector<double>(k, 0.0));
			calcKNN(origJaccard, distJaccard, wine, knn, names, distKNN, numCol, numWine, k);
		}
		//cin >> go;
	}

	/*for (int i = 0; i < numWine; i++)
	{
		cout << distJaccard[i][0];
		cout << endl;
	}*/

	cin >> stuff;
}